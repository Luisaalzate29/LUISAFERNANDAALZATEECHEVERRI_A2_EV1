

package com.example.facturacionserviciosapp.data.models

data class Cliente(
    val id: Int,
    val nroIdentificacion: String,
    val nombreCompleto: String,
    val direccion: String,
    val barrio: String,
    val ciudad: String,
    val departamento: String,
    val nroContadorAgua: String,
    val nroContadorLuz: String
)
