package com.example.facturacionserviciosapp.data.models

data class Empleador(
    val nombre: String,
    val nroIdentificacion: String,
    val nroDocumento: String,
    val correoInstitucional: String,
    val contraseña: String
)
