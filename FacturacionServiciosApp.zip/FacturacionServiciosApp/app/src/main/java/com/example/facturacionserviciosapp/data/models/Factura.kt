package com.example.facturacionserviciosapp.data.models

data class Factura(
    val nombreCompleto: String,
    val direccion: String,
    val consumoAgua: Double,
    val consumoLuz: Double,
    val valorLitro: Double,
    val valorKv: Double
)
