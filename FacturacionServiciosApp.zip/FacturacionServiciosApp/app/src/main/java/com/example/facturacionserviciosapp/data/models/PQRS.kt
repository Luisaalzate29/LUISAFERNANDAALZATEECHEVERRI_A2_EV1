package com.example.facturacionserviciosapp.data.models

data class PQRS(
    val clienteId: Int,
    val tipo: String,
    val mensaje: String,
    val fecha: String
)
