package com.example.facturacionserviciosapp.data.network

import com.example.facturacionserviciosapp.data.models.*
import retrofit2.Response
import retrofit2.http.*

interface ApiService {

    @GET("clientes")
    suspend fun obtenerClientes(): Response<List<Cliente>>

    @POST("clientes")
    suspend fun registrarCliente(@Body cliente: Cliente): Response<ApiResponse>

    @PUT("clientes/{id}")
    suspend fun actualizarCliente(@Path("id") id: Int, @Body cliente: Cliente): Response<ApiResponse>

    @GET("factura/{identificacion}/{fecha}")
    suspend fun consultarFactura(
        @Path("identificacion") id: String,
        @Path("fecha") fecha: String
    ): Response<Factura>

    @GET("contadores/{id}")
    suspend fun obtenerContadores(@Path("id") idCliente: Int): Response<List<Contador>>

    @POST("pqrs")
    suspend fun enviarPQRS(@Body pqrs: PQRS): Response<ApiResponse>
}
