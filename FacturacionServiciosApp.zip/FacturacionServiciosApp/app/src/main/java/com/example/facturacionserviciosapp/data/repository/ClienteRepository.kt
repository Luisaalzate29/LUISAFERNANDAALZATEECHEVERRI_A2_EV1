package com.example.facturacionserviciosapp.data.repository

import com.example.facturacionserviciosapp.data.models.Cliente
import com.example.facturacionserviciosapp.data.network.ApiService
import retrofit2.Response

class ClienteRepository(private val api: ApiService) {

    suspend fun obtenerClientes(): List<Cliente> {
        val response = api.obtenerClientes()
        return response.body() ?: emptyList()
    }

    suspend fun registrarCliente(cliente: Cliente): Response<ApiResponse> {
        return api.registrarCliente(cliente)
    }

    suspend fun actualizarCliente(id: Int, cliente: Cliente): Response<ApiResponse> {
        return api.actualizarCliente(id, cliente)
    }
}
