package com.example.facturacionserviciosapp.data.repository

import com.example.facturacionserviciosapp.data.models.Contador
import com.example.facturacionserviciosapp.data.network.ApiService

class ContadorRepository(private val api: ApiService) {
    suspend fun obtenerContadores(idCliente: Int): List<Contador> {
        val response = api.obtenerContadores(idCliente)
        return response.body() ?: emptyList()
    }
}
