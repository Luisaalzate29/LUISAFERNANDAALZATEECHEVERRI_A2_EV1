package com.example.facturacionserviciosapp.data.repository

import com.example.facturacionserviciosapp.data.models.Factura
import com.example.facturacionserviciosapp.data.network.ApiService

class FacturaRepository(private val api: ApiService) {
    suspend fun consultarFactura(id: String, fecha: String): Factura? {
        val response = api.consultarFactura(id, fecha)
        return if (response.isSuccessful) response.body() else null
    }
}
