package com.example.facturacionserviciosapp.data.repository

class PQRSRepository {
}