


interface ApiService {
    @GET("factura/{id}")
    suspend fun obtenerFactura(@Path("id") idCliente: Int): Response<Factura>
}