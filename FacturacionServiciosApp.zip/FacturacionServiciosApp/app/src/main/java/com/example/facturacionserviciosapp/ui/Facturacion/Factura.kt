data class Factura(
    val idCliente: Int,
    val nombreCompleto: String,
    val direccion: String,
    val nroContadorAgua: String,
    val nroContadorLuz: String,
    val consumoAgua: Double,
    val consumoLuz: Double,
    val valorLitro: Double,
    val valorKv: Double
) {
    val totalPagar: Double
        get() = (consumoAgua * valorLitro) + (consumoLuz * valorKv)
}
