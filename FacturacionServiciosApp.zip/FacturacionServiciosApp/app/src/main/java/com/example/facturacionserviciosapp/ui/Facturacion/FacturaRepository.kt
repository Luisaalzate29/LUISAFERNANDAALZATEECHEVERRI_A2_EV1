package com.example.facturacionserviciosapp.ui.Facturacion

class FacturaRepository(private val api: ApiService) {
    suspend fun getFactura(idCliente: Int): Factura? {
        val response = api.obtenerFactura(idCliente)
        return if (response.isSuccessful) response.body() else null
    }
}