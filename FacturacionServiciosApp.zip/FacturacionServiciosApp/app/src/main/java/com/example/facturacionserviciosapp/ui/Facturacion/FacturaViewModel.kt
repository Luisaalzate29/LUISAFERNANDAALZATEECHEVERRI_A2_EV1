package com.example.facturacionserviciosapp.ui.Facturacion

class FacturaViewModel(private val repository: FacturaRepository) : ViewModel() {
    private val _factura = MutableLiveData<Factura>()
    val factura: LiveData<Factura> get() = _factura

    fun cargarFactura(idCliente: Int) {
        viewModelScope.launch {
            val resultado = repository.getFactura(idCliente)
            resultado?.let { _factura.value = it }
        }
    }
}
