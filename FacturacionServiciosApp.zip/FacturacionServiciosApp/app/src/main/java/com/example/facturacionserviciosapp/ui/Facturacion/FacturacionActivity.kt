package com.example.facturacionserviciosapp.ui.Facturacion

class FacturacionActivity : AppCompatActivity() {
    private lateinit var viewModel: FacturaViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_facturacion)

        val idCliente = intent.getIntExtra("idCliente", 0)
        viewModel = ViewModelProvider(this)[FacturaViewModel::class.java]
        viewModel.cargarFactura(idCliente)

        viewModel.factura.observe(this) { factura ->
            findViewById<TextView>(R.id.tvNombre).text = factura.nombreCompleto
            findViewById<TextView>(R.id.tvDireccion).text = factura.direccion
            findViewById<TextView>(R.id.tvContadorAgua).text = factura.nroContadorAgua
            findViewById<TextView>(R.id.tvContadorLuz).text = factura.nroContadorLuz
            findViewById<TextView>(R.id.tvConsumoAgua).text = "${factura.consumoAgua} L"
            findViewById<TextView>(R.id.tvConsumoLuz).text = "${factura.consumoLuz} kV"
            findViewById<TextView>(R.id.tvTotalPagar).text = "$${factura.totalPagar}"
        }
    }
}
