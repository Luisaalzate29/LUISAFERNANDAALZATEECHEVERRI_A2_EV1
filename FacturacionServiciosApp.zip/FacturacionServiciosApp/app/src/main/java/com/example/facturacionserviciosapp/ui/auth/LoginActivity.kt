package com.example.facturacionserviciosapp.ui.auth

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.example.facturacionserviciosapp.databinding.ActivityLoginBinding
import com.example.facturacionserviciosapp.ui.menu.MenuActivity

class LoginActivity : AppCompatActivity() {
    private lateinit var binding: ActivityLoginBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnIngresar.setOnClickListener {
            val email = binding.etCorreo.text.toString()
            val password = binding.etPassword.text.toString()

            FirebaseAuth.getInstance().signInWithEmailAndPassword(email, password)
                .addOnSuccessListener {
                    startActivity(Intent(this, MenuActivity::class.java))
                }
                .addOnFailureListener {
                    Toast.makeText(this, "Error al ingresar", Toast.LENGTH_SHORT).show()
                }
        }
    }
}