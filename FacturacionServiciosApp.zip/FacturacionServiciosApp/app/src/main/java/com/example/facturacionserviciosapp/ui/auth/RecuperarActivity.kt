package com.example.facturacionserviciosapp.ui.auth

class RecuperarActivity : AppCompatActivity() {
    private lateinit var binding: ActivityRecuperarBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRecuperarBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnRecuperar.setOnClickListener {
            val email = binding.etCorreo.text.toString()
            FirebaseAuth.getInstance().sendPasswordResetEmail(email)
                .addOnSuccessListener {
                    Toast.makeText(this, "Correo enviado", Toast.LENGTH_SHORT).show()
                }
                .addOnFailureListener {
                    Toast.makeText(this, "Error al enviar correo", Toast.LENGTH_SHORT).show()
                }
        }
    }
}
