package com.example.facturacionserviciosapp.ui.comercial

data class ClienteNuevo(
    val nombreCompleto: String,
    val nroIdentificacion: String,
    val direccion: String,
    val ciudad: String,
    val barrio: String,
    val departamento: String,
    val servicios: List<String> // Agua, Luz, etc.
)
