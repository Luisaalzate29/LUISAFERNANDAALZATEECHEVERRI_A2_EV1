package com.example.facturacionserviciosapp.ui.contadores

interface ApiService {
    @GET("contadores/{id}")
    suspend fun obtenerContadores(@Path("id") idCliente: Int): Response<List<Contador>>
}
