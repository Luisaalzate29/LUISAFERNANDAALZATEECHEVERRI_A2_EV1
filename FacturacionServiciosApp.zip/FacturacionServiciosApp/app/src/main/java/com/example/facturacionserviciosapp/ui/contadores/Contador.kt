package com.example.facturacionserviciosapp.ui.contadores

data class Contador(
    val idCliente: Int,
    val nombreCompleto: String,
    val nroContadorAgua: String,
    val nroContadorLuz: String,
    val consumoDiarioAgua: Double,
    val consumoDiarioLuz: Double,
    val fecha: String
)
