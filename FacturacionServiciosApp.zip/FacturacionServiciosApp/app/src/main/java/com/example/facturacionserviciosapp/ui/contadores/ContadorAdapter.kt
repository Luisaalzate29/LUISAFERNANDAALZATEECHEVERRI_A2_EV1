package com.example.facturacionserviciosapp.ui.contadores

class ContadorAdapter : ListAdapter<Contador, ContadorAdapter.ViewHolder>(DiffCallback()) {
    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        fun bind(contador: Contador) {
            itemView.findViewById<TextView>(R.id.tvFecha).text = contador.fecha
            itemView.findViewById<TextView>(R.id.tvAgua).text = "${contador.consumoDiarioAgua} L"
            itemView.findViewById<TextView>(R.id.tvLuz).text = "${contador.consumoDiarioLuz} kV"
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_contador, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    class DiffCallback : DiffUtil.ItemCallback<Contador>() {
        override fun areItemsTheSame(oldItem: Contador, newItem: Contador) = oldItem.fecha == newItem.fecha
        override fun areContentsTheSame(oldItem: Contador, newItem: Contador) = oldItem == newItem
    }
}
