package com.example.facturacionserviciosapp.ui.contadores

class ContadorRepository(private val api: ApiService) {
    suspend fun getContadores(idCliente: Int): List<Contador> {
        val response = api.obtenerContadores(idCliente)
        return response.body() ?: emptyList()
    }
}
