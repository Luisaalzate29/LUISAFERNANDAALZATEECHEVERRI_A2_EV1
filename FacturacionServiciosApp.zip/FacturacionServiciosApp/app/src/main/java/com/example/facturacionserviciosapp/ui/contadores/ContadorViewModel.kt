package com.example.facturacionserviciosapp.ui.contadores

class ContadorViewModel(private val repository: ContadorRepository) : ViewModel() {
    private val _contadores = MutableLiveData<List<Contador>>()
    val contadores: LiveData<List<Contador>> get() = _contadores

    fun cargarContadores(idCliente: Int) {
        viewModelScope.launch {
            val resultado = repository.getContadores(idCliente)
            _contadores.value = resultado
        }
    }
}
