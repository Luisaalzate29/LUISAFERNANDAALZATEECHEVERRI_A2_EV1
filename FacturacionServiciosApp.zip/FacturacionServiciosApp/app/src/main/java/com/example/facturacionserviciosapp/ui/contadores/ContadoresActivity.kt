package com.example.facturacionserviciosapp.ui.contadores

class ContadoresActivity : AppCompatActivity() {
    private lateinit var viewModel: ContadorViewModel
    private lateinit var adapter: ContadorAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_contadores)

        val idCliente = intent.getIntExtra("idCliente", 0)
        adapter = ContadorAdapter()
        findViewById<RecyclerView>(R.id.rvContadores).adapter = adapter

        viewModel = ViewModelProvider(this)[ContadorViewModel::class.java]
        viewModel.cargarContadores(idCliente)

        viewModel.contadores.observe(this) { lista ->
            if (lista.isNotEmpty()) {
                findViewById<TextView>(R.id.tvNombreCliente).text = lista[0].nombreCompleto
                adapter.submitList(lista)
            }
        }
    }
}
