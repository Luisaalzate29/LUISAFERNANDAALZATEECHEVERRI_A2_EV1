package com.example.facturacionserviciosapp.ui.menu

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import com.example.facturacionserviciosapp.R
import com.example.facturacionserviciosapp.ui.facturacion.FacturacionActivity
import com.example.facturacionserviciosapp.ui.contadores.ContadoresActivity
import com.example.facturacionserviciosapp.ui.servicioCliente.ServicioClienteActivity
import com.example.facturacionserviciosapp.ui.comercial.ComercialActivity

class MenuActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_menu)

        findViewById<Button>(R.id.btnFacturacion).setOnClickListener {
            startActivity(Intent(this, FacturacionActivity::class.java))
        }

        findViewById<Button>(R.id.btnContadores).setOnClickListener {
            startActivity(Intent(this, ContadoresActivity::class.java))
        }

        findViewById<Button>(R.id.btnServicioCliente).setOnClickListener {
            startActivity(Intent(this, ServicioClienteActivity::class.java))
        }

        findViewById<Button>(R.id.btnComercial).setOnClickListener {
            startActivity(Intent(this, ComercialActivity::class.java))
        }
    }
}
