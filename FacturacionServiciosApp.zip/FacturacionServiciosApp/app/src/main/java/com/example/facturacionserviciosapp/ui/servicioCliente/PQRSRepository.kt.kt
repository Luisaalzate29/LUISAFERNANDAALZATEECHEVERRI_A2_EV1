package com.example.facturacionserviciosapp.ui.servicioCliente


    data class `PQRSRepository.kt`(
        val clienteId: Int,
        val tipo: String, // Petición, Queja, etc.
        val mensaje: String,
        val fecha: String
    )

