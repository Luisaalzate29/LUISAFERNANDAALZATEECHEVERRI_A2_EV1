package com.tuempresa.facturacionservicios.utils

import java.text.SimpleDateFormat
import java.util.*

object FormateadorFechas {

    fun obtenerFechaActual(): String {
        val formato = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        return formato.format(Date())
    }

    fun esFormatoValido(fecha: String): Boolean {
        return try {
            SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).parse(fecha)
            true
        } catch (e: Exception) {
            false
        }
    }

    fun formatearParaMostrar(fecha: String): String {
        val original = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        val destino = SimpleDateFormat("dd 'de' MMMM 'de' yyyy", Locale("es", "CO"))
        val date = original.parse(fecha)
        return destino.format(date!!)
    }
}
