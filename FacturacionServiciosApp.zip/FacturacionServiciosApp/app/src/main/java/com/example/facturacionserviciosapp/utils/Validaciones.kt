package com.tuempresa.facturacionservicios.utils

object Validaciones {

    fun esCorreoValido(correo: String): Boolean {
        return android.util.Patterns.EMAIL_ADDRESS.matcher(correo).matches()
    }

    fun esIdentificacionValida(id: String): Boolean {
        return id.length in 6..12 && id.all { it.isDigit() }
    }

    fun campoNoVacio(texto: String): Boolean {
        return texto.trim().isNotEmpty()
    }

    fun esNumeroPositivo(valor: String): Boolean {
        return valor.toDoubleOrNull()?.let { it >= 0 } ?: false
    }
}
