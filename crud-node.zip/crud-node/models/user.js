const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
  nombre: {
    type: String,
    required: true,
    trim: true
  },
  email: {
    type: String,
    required: true,
    unique: true,
    lowercase: true
  },
  ciudad: {
    type: String,
    enum: ['Santa Marta', 'Cartagena', 'Barranquilla', 'Bogotá', 'Medellín'],
    default: 'Santa Marta'
  },
  cultura: {
    type: String,
    enum: ['Wayuu', 'Palenquera', 'Muisca', 'Zenú', 'Embera'],
    default: 'Wayuu'
  },
  rol: {
    type: String,
    default: 'Usuario'
  },
  activo: {
    type: Boolean,
    default: true
  },
  fechaRegistro: {
    type: Date,
    default: Date.now
  }
});

module.exports = mongoose.model('User', userSchema);
