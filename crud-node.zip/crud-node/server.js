const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const cors = require('cors');
const User = require('./models/user');

const app = express();
app.use(cors());
app.use(bodyParser.json());

// Conexión a MongoDB (ajusta tu URI si usas Compass local)
mongoose.connect('mongodb://localhost:27017/cruddb', {
  useNewUrlParser: true,
  useUnifiedTopology: true
});

// Rutas CRUD

// GET - Obtener todos los usuarios
app.get('/users', async (req, res) => {
  const users = await User.find();
  res.json(users);
});

// POST - Crear nuevo usuario
app.post('/users', async (req, res) => {
  const newUser = new User(req.body);
  await newUser.save();
  res.json(newUser);
});

// PUT - Actualizar usuario
app.put('/users/:id', async (req, res) => {
  const updatedUser = await User.findByIdAndUpdate(req.params.id, req.body, { new: true });
  res.json(updatedUser);
});

// DELETE - Eliminar usuario
app.delete('/users/:id', async (req, res) => {
  await User.findByIdAndDelete(req.params.id);
  res.json({ message: 'Usuario eliminado' });
});

// Iniciar servidor
app.listen(3000, () => {
  console.log('Servidor corriendo en http://localhost:3000');
});

const nuevoUsuario = new User({
  nombre: 'Luisa Martínez',
  email: 'luisa@example.com',
  ciudad: 'Santa Marta',
  cultura: 'Wayuu',
  rol: 'Diseñadora Frontend'
});

await nuevoUsuario.save();
app.post('/api/users', async (req, res) => {
  try {
    const nuevoUsuario = new User(req.body);
    const usuarioGuardado = await nuevoUsuario.save();
    res.status(201).json(usuarioGuardado);
  } catch (error) {
    res.status(400).json({ mensaje: 'Error al crear usuario', error });
  }
});