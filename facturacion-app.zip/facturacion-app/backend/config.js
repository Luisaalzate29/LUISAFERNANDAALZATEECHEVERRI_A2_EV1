const mysql = require('mysql2');

const conexion = mysql.createConnection({
  host: 'localhost',
  user: 'tu_usuario',
  password: 'tu_contraseña',
  database: 'nombre_base_datos'
});

conexion.connect((err) => {
  if (err) console.error('❌ Error al conectar a MySQL:', err);
  else console.log('✅ Conectado a MySQL');
});

module.exports = conexion;

