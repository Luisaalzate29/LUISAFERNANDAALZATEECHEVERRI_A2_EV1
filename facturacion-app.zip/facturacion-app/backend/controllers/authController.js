exports.recuperar = async (req, res) => {
  const { correo, nuevaClave } = req.body;
  const hash = await bcrypt.hash(nuevaClave, 10);

  const sql = 'UPDATE usuar SET contraseña = ? WHERE correo = ?';
  db.query(sql, [hash, correo], (err, result) => {
    if (err) return res.status(500).send('Error al actualizar contraseña');
    if (result.affectedRows === 0) return res.status(404).send('Correo no encontrado');
    res.send('Contraseña actualizada correctamente');
  });
};
