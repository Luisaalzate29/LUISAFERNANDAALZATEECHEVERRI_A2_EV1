const express = require('express');
const router = express.Router();
const db = require('../config');

router.post('/nuevo', (req, res) => {
  const {
    nro_identificacion,
    nombre_completo,
    direccion,
    barrio,
    ciudad,
    departamento,
    servicio_agua,
    servicio_luz
  } = req.body;

  const sql = `
    INSERT INTO clientes (
      nro_identificacion, nombre_completo, direccion, barrio,
      ciudad, departamento, servicio_agua, servicio_luz
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `;

  db.query(sql, [
    nro_identificacion,
    nombre_completo,
    direccion,
    barrio,
    ciudad,
    departamento,
    servicio_agua ? 1 : 0,
    servicio_luz ? 1 : 0
  ], (err) => {
    if (err) return res.status(500).send('Error al registrar cliente');
    res.send('Cliente registrado exitosamente');
  });
});

module.exports = router;
