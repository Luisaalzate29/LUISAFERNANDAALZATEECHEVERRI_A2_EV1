// backend/routes/contadores.js

const express = require('express');
const router = express.Router();
const db = require('../config');

router.get('/:cliente_id', (req, res) => {
  const { cliente_id } = req.params;
  db.query('SELECT * FROM contadores WHERE cliente_id = ?', [cliente_id], (err, results) => {
    if (err) return res.status(500).send(err);
    res.json(results);
  });
});

module.exports = router;
