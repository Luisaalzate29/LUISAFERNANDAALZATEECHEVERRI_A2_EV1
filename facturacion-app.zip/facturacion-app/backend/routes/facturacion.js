// backend/routes/facturacion.js

const express = require('express');
const router = express.Router();
const { generarFactura, verFactura } = require('../controllers/facturacionController');

router.post('/generar', generarFactura);
router.get('/ver/:id', verFactura);

module.exports = router;
