// backend/routes/servicio.js

const express = require('express');
const router = express.Router();
const db = require('../config');

router.get('/factura/:id', (req, res) => {
  const { id } = req.params;
  db.query('SELECT * FROM facturas WHERE cliente_id = ?', [id], (err, results) => {
    if (err) return res.status(500).send(err);
    res.json(results);
  });
});

router.post('/pqrs', (req, res) => {
  const { cliente_id, tipo, descripcion } = req.body;
  db.query('INSERT INTO pqrs SET ?', {
    cliente_id, tipo, descripcion, fecha: new Date()
  }, (err) => {
    if (err) return res.status(500).send(err);
    res.send('PQRS registrada');
  });
});

module.exports = router;
