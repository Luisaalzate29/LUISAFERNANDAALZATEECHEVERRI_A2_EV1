-- database/schema.sql

CREATE DATABASE facturacion;

USE facturacion;

CREATE TABLE usuar (
   correo VARCHAR(255) NOT NULL UNIQUE,
  contraseña VARCHAR(255) NOT NULL
);

CREATE TABLE cliente (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nro_identificacion VARCHAR(20),
  nombre_completo VARCHAR(100),
  direccion VARCHAR(100),
  barrio VARCHAR(50),
  ciudad VARCHAR(50),
  departamento VARCHAR(50),
  consumo_agua DECIMAL(10,2),
  consumo_luz DECIMAL(10,2),
  valor_litro DECIMAL(10,2),
  valor_kv DECIMAL(10,2)
);

CREATE TABLE contadores (
  id INT AUTO_INCREMENT PRIMARY KEY,
  cliente_id INT,
  nro_contador_agua VARCHAR(20),
  nro_contador_luz VARCHAR(20),
  consumo_agua_dia DECIMAL(10,2),
  consumo_luz_dia DECIMAL(10,2),
  fecha DATE,
  FOREIGN KEY (cliente_id) REFERENCES clientes(id)
);

CREATE TABLE facturas (
  id INT AUTO_INCREMENT PRIMARY KEY,
  cliente_id INT,
  fecha DATE,
  total_pago DECIMAL(10,2),
  FOREIGN KEY (cliente_id) REFERENCES clientes(id)
);

CREATE TABLE pqrs (
  id INT AUTO_INCREMENT PRIMARY KEY,
  cliente_id INT,
  tipo VARCHAR(50),
  descripcion TEXT,
  fecha DATE,
  FOREIGN KEY (cliente_id) REFERENCES clientes(id)
);
